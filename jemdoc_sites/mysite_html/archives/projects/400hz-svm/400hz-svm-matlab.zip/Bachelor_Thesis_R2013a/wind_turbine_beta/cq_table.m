
load cp_cq;

Ctorque=cq(2:5:102,2:5:182);

clear Cp cq