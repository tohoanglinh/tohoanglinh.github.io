# Copyright Hoang-Linh TO, 2009
# Website: http://goo.gl/C4G7u3

# Installation

Put wind_turbine_beta folder into MATLAB search path (Add to path)

# Run

, run parameter.m
, run source400Hz.mdl