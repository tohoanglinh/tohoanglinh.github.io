%------------------------------------------------------------
%           DO AN TOT NGHIEP - NGANH TDH - 04-09
% Ten de tai      : Thiet ke bo nguon xoay chieu 3 pha 400HZ.
% Nguoi huong dan : TS. TRAN TRONG MINH.
% Nguoi thuc hien : TO HOANG LINH.
% Lop             : TDH1 - K49.
% MSSV            : 20041812.
disp('VOLTAGE SOURCE - 3 PHASE - 400HZ')
%------------------------------------------------------------
% Thong so mach luc !
L = 1e-3;     % Henry. Cuon Loc L.
C = 5e-5;     % Farah. Tu Loc C.
Udc = 515;    % V. Dien ap sau chinh luu.
%------------------------------------------------------------
% Thong so bo dieu khien !
% Bo dieu khien dong dien
Kp_i = 5;
Ki_i = 500;
% Bo dieu khien dien ap
Kp_u = 0.1;
Ki_u = 156;
%------------------------------------------------------------
% Thong so phu
T_s = 2e-5;     %Chu ky trich mau.
F_pulse=10000;  %Tan so bam xung
freq = 400;     %Tan so hoat dong
w=2*3.14*freq;
U = 200;        %Volts. Dien ap hieu dung dau ra.
Uq = 0;  
Ud = sqrt(2*U*U-Uq*Uq);
%------------------------------------------------------------