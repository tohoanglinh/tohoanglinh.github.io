/*******************************************************************************
;	main.c la chuong trinh MAIN !			   								   *
;***************************************************************************** *
;	Tac gia				: To Hoang Linh 									   *
;	Don vi				: Dai hoc Bach Khoa Ha Noi							   *
;	Ten tap tin			: main.c									   		   *
;	Ngay				: 30/05/2009										   *
;	Phien ban			: 1.0												   *
;	Nhung tap tin can thiet khac: svm.h, p30f4011.h				   			   *
;-------------------------------------------------------------------------------
;	Phan cung giao tiep LCD.
;					LCD_EN = RC14											   *
;					LCD_RS = RC13											   *
;					LCD_DAT (D7..D4) = RD3..RD0								   *
;	Chuong trinh nay dung che do giao tiep 4-bit voi LCD
;-------------------------------------------------------------------------------
;	Phan cung giao tiep Potentiometer.
;					ADC = PORTB												   *
;	Chuong trinh nay dung de doc gia tri dien ap tu 0 - 5V o portB
;-------------------------------------------------------------------------------
;	Phan cung giao tiep RS232.
;					UART2 = RF4_U2RX, RF5_U2TX								   *
;	Chuong trinh nay dung de giao tiep voi PC
;-------------------------------------------------------------------------------
;	Cong cu duoc dung:	MPLAB 8.30 (2009 - 2014)							   *
;						C30 3.8.5 (2009), C30 3.31 (2014)					   *
;-------------------------------------------------------------------------------
; How to run																   *
- Run --> build all															   *
- Or Animate --> build all, see logic analyzer at 3 ports PWM1H,2H,3H		   *	
*******************************************************************************/
#include "svm.h"
_FOSC(CSW_FSCM_OFF & XT_PLL4);		// XTL = 8Mhz --> speed = 8MIPS
_FWDT(WDT_OFF);
_FBORPOR(MCLR_EN & PBOR_OFF);
_FGS(CODE_PROT_OFF);
//===================================================================
void __attribute__((interrupt, auto_psv)) _PWMInterrupt (void)
{
	IFS2bits.PWMIF = 0;	// Clear interrupt flag
	if (phase_angle < 0xffdc){
	phase_angle += delta_phase;
	}
	if (phase_angle >= 0xffdc)
	{
	phase_angle = 0;
	}
	SVM(phase_angle);	
	return;
}
//===================================================================
int main(void)
{
	InitUserInt();
	InitMCPWM();
	phase_angle = 0;
	SVM(phase_angle);
	for(;;)
	{	// Do nothing	
	}
	return 0;
}
//===================================================================
#define deadtime 1e-6			//Dead time = 1us
void InitMCPWM(void)
{
// PWM pins as outputs, FLTA as input
	TRISE = 0x0100;

// Compute Period for Desired PWM Frequency
	PTPER = (FCY/FPWM - 1) >> 1;

// Temporarily disable all PWM outputs.
	OVDCON = 0x0000;

// ~1us of deadtime, 16MIPS and 1:1 Deadtime Prescaler.
	DTCON1 = DEADTIME;

// Enable PWM Output pins & Complementary Mode.
	PWMCON1 = 0x0077;

// Interrupt
	IFS2bits.PWMIF = 0;
	IEC2bits.PWMIE = 1;

// PWM Outputs are controlled by PWM Module.
	OVDCON = 0x3F00;

// Center Aligned PWM Operation
	PTCONbits.PTMOD = 2;

// Reset Phase Variable
	Phase = 0;

// Initialize Phase Increment for 400Hz Sine Wave
	Delta_Phase = delta_phase;

// START PWM
	PTCONbits.PTEN = 1;
	return;				 
}
//===================================================================
void InitUserInt(void)
{
	LATB = 0;
	TRISB = 0xffff;
	ADPCFG = 0;
	return;
}
//=================================================================
/*---------------------------------------------------------------------
Ham SVM() tim sector ma goc nhap vao dang nam tren. Sau do goc dieu che
duoc chuan hoa ve sector hien tai. 2 gia tri goc duoc tinh toan tu goc
duoc chuan hoa. Hai goc nay giup xac dinh thoi cho cac vector T1 va T2.
Cac vector T1 va T2 sau do duoc chuan hoa theo bien do dieu che va chu ky
bam xung tpwm. Cuoi cung, thoi gian vector T0 la thoi gian con lai trong
tong chu ky dieu che PWM
Sau khi tim duoc T1, T2, T0, ham SVM se tinh toan 3 gia tri duty cycle
tu cac khoang thoi gian nay. Viec phat ra cac duty cycle phu thuoc vao
sector hien thoi.
---------------------------------------------------------------------*/
void SVM(unsigned int angle)
{
/* Tinh toan tong chu ky thuc hien PWM, tpwm = 2*ptper
(Vi PTPER co do lon 15bit (max=0x7fff), tpwm la gia tri can tinh
de nap vao PDC, co do lon 16bit --> tpwm phai co gia tri max gap doi
PTPER)*/
tpwm = PTPER << 1;	// Vi phep dich trai se can it chu ky lenh hon phep nhan.

if(angle < VECTOR2)
	{
	angle2 = angle - VECTOR1;		// Reference SVM angle to the current sector
	angle1 = SIXTY_DEG - angle2;	// Calculate second angle referenced to sector

	scale_t();

	half_t0 = (tpwm - t1 - t2) >> 1;		// Calculate half_t0 null time from period and t1,t2
	
	// Calculate duty cycles for Sector 1  (0 - 59 degrees)
	PDC1 = t1 + t2 + half_t0;
	PDC2 = t2 + half_t0;
	PDC3 = half_t0;
	}
else if(angle < VECTOR3)
	{
	angle2 = angle - VECTOR2;		// Reference SVM angle to the current sector
	angle1 = SIXTY_DEG - angle2;	// Calculate second angle referenced to sector

	scale_t();

	half_t0 = (tpwm - t1 - t2) >> 1;		// Calculate half_t0 null time from period and t1,t2
	
	// Calculate duty cycles for Sector 2  (60 - 119 degrees)
	PDC1 = t1 + half_t0;
	PDC2 = t1 + t2 + half_t0;
	PDC3 = half_t0;
	}

else if(angle < VECTOR4)
	{
	angle2 = angle - VECTOR3;		// Reference SVM angle to the current sector
	angle1 = SIXTY_DEG - angle2;	// Calculate second angle referenced to sector

	scale_t();

	half_t0 = (tpwm - t1 - t2) >> 1;		// Calculate half_t0 null time from period and t1,t2
	
	// Calculate duty cycles for Sector 3  (120 - 179 degrees)
	PDC1 = half_t0;
	PDC2 = t1 + t2 + half_t0;
	PDC3 = t2 + half_t0;
	}

else if(angle < VECTOR5)		
	{
	angle2 = angle - VECTOR4;		// Reference SVM angle to the current sector
	angle1 = SIXTY_DEG - angle2;	// Calculate second angle referenced to sector

	scale_t();

	half_t0 = (tpwm - t1 - t2) >> 1;		// Calculate half_t0 null time from period and t1,t2
	
	// Calculate duty cycles for Sector 4  (180 - 239 degrees)
	PDC1 = half_t0;
	PDC2 = t1 + half_t0;
	PDC3 = t1 + t2 + half_t0;
	}

else if(angle < VECTOR6)
	{
	angle2 = angle - VECTOR5;		// Reference SVM angle to the current sector
	angle1 = SIXTY_DEG - angle2;	// Calculate second angle referenced to sector

	scale_t();

	half_t0 = (tpwm - t1 - t2) >> 1;		// Calculate half_t0 null time from period and t1,t2
	
	// Calculate duty cycles for Sector 5  (240 - 299 degrees)
	PDC1 = t2 + half_t0;
	PDC2 = half_t0;
	PDC3 = t1 + t2 + half_t0;
	}

else
	{
	angle2 = angle - VECTOR6;		// Reference SVM angle to the current sector
	angle1 = SIXTY_DEG - angle2;	// Calculate second angle referenced to sector

	scale_t();

	half_t0 = (tpwm - t1 - t2) >> 1;		// Calculate half_t0 null time from period and t1,t2
	
	// Calculate duty cycles for Sector 6  ( 300 - 359 degrees )
	PDC1 = t1 + t2 + half_t0;
	PDC2 = half_t0;
	PDC3 = t1 + half_t0;
	}
}			// end SVM()
//=================================================================
void scale_t(void) {

t1 = sinetable[(unsigned char)(angle1 >> nbit)];	// Look up values from table.
t2 = sinetable[(unsigned char)(angle2 >> nbit)];

	// Scale t1 for the duty cycle range.
	t1 = ((long)t1*(long)tpwm) >> 15;
	// Scale t2 time
	t2 = ((long)t2*(long)tpwm) >> 15;
}
